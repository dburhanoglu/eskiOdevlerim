package hopenihai;

import java.util.Scanner;

public abstract class Soru {

protected abstract void soruEkle();

protected abstract void soruSil();

protected abstract void soruS�rala();

protected  abstract void Sorukaristir();//burada sorular� kar���k s�raya almay� ama�lam��t�k







}
