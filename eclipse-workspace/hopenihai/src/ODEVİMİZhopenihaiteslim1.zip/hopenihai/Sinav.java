package hopenihai;

import java.io.Serializable;
import java.util.Vector;

public abstract class Sinav implements Serializable{//bu klasla soru klas� aras�nda association olmal� fakat biz uygun bir kod yazamad�k

protected abstract void SinavOlustur();

}
