package hopenihai;

public interface NotHesaplanabilme {
	 abstract void notHesapla();
		
}
