package S�NAV�;

public abstract class Hesap {

}
