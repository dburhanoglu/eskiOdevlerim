package S�NAV�;

public class KurumsalHesap {

}
