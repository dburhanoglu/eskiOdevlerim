package S�NAV�;

public interface IGuvenlikKontrol {
public void yetkiKontrol();
}
